/*
 * Brandon Dalton
 * 9/9/19
 * This program demos switch statements and different loops
 */
package hw_02_daltonbrandon;
import javax.swing.JOptionPane;
public class HW_02_DaltonBrandon 
{

    public static void main(String[] args) 
    {       
       String prompt;
       String[] options = {"1.While Loop","2.Do While Loop","3.For Loop"};
       int choice;
       do
       {      
       choice = JOptionPane.showOptionDialog(null, "Please choose an option.",
               "Choose an option", JOptionPane.DEFAULT_OPTION,
               JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);       
        switch (choice)
       {
            case 0:
                whileLoop();
            break;
            case 1:
                doWhileLoop();
            break;
            case 2:
                forLoop();
       }       
        prompt = JOptionPane.showInputDialog("Do you want to run this program"
                + " again?");
        while(!(prompt.equalsIgnoreCase("yes")||prompt.equalsIgnoreCase("no")))
        {
            prompt = JOptionPane.showInputDialog("Error! Please enter Yes or No"
                    + ".\nDo you want to run this program again?");               
        }
       }while(prompt.equalsIgnoreCase("Yes"));
    }
    public static void whileLoop()
    {        
        int counter = 0;        
        String input = JOptionPane.showInputDialog("Would you like to run the "
                + "while loop?");
        while (!(input.equalsIgnoreCase("yes")||input.equalsIgnoreCase("no")))
        {
            input = JOptionPane.showInputDialog("Error! Please enter Yes or No."
                    + "\nWould you like to run the while loop?");
        }
        while (input.equalsIgnoreCase("Yes"))
        {
            counter++;           
            JOptionPane.showMessageDialog(null, "You have ran the while loop "
                    +counter+" times");
            input = JOptionPane.showInputDialog("Would you like to run the "
                    + "while loop again?");
        }
    }
    public static void doWhileLoop()
    {        
        String prompt;
        do
        {            
            prompt = JOptionPane.showInputDialog("This is a do-while loop."
                    + "\nWould you like to run the do-while loop again?");
            while(!(prompt.equalsIgnoreCase("yes")||
                    prompt.equalsIgnoreCase("no")))
            {
                prompt = JOptionPane.showInputDialog("Error! Please enter "
                        + "Yes or No.\nThis is a do-while loop. Would you like"
                        + " to run the do-while loop again?");
            }
        }while(prompt.equalsIgnoreCase("Yes"));
    }
    public static void forLoop()
    {
        int count=0;
        while (count==0)
        {
        try
        {
          count = Integer.parseInt(JOptionPane.showInputDialog("This is a for"
                + " loop, how many times would you like to run the for loop?"
                  + "\n(Enter a number between 1 and 5.)"));
          while (count>5 || count <= 0)
          {
              count =0;
              count = Integer.parseInt(JOptionPane.showInputDialog("Error! "
                      + "Please enter a number between 1 and 5."));
          }
        }catch (NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null,"Error! Please enter a number");
        }
        }
        for(int i=0;i<count;i++)
        {           
            JOptionPane.showMessageDialog(null, "Loop "+(i+1));
        }
    }
    
}
